﻿#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include "glm/glm.hpp"
#include <glm/gtx/string_cast.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/matrix_inverse.hpp>

#include <array>
#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <math.h>

using namespace std;

static int WIN_WIDTH = 600;
static int WIN_HEIGHT = 600;

float cube1[] = {

-0.5f, -0.5f, -0.5f,
 0.5f, -0.5f, -0.5f,
 0.5f,  0.5f, -0.5f,
 0.5f,  0.5f, -0.5f,
-0.5f,  0.5f, -0.5f,
-0.5f, -0.5f, -0.5f,

-0.5f, -0.5f,  0.5f,
 0.5f, -0.5f,  0.5f,
 0.5f,  0.5f,  0.5f,
 0.5f,  0.5f,  0.5f,
-0.5f,  0.5f,  0.5f,
-0.5f, -0.5f,  0.5f,

-0.5f,  0.5f,  0.5f,
-0.5f,  0.5f, -0.5f,
-0.5f, -0.5f, -0.5f,
-0.5f, -0.5f, -0.5f,
-0.5f, -0.5f,  0.5f,
-0.5f,  0.5f,  0.5f,

 0.5f,  0.5f,  0.5f,
 0.5f,  0.5f, -0.5f,
 0.5f, -0.5f, -0.5f,
 0.5f, -0.5f, -0.5f,
 0.5f, -0.5f,  0.5f,
 0.5f,  0.5f,  0.5f,

-0.5f, -0.5f, -0.5f,
 0.5f, -0.5f, -0.5f,
 0.5f, -0.5f,  0.5f,
 0.5f, -0.5f,  0.5f,
-0.5f, -0.5f,  0.5f,
-0.5f, -0.5f, -0.5f,

-0.5f,  0.5f, -0.5f,
 0.5f,  0.5f, -0.5f,
 0.5f,  0.5f,  0.5f,
 0.5f,  0.5f,  0.5f,
-0.5f,  0.5f,  0.5f,
-0.5f,  0.5f, -0.5f,

};

float cube2[] = {

-0.5f, -0.5f, 1.5f,
 0.5f, -0.5f, 1.5f,
 0.5f,  0.5f, 1.5f,
 0.5f,  0.5f, 1.5f,
-0.5f,  0.5f, 1.5f,
-0.5f, -0.5f, 1.5f,

-0.5f, -0.5f, 2.5f,
 0.5f, -0.5f, 2.5f,
 0.5f,  0.5f, 2.5f,
 0.5f,  0.5f, 2.5f,
-0.5f,  0.5f, 2.5f,
-0.5f, -0.5f, 2.5f,

-0.5f,  0.5f, 2.5f,
-0.5f,  0.5f, 1.5f,
-0.5f, -0.5f, 1.5f,
-0.5f, -0.5f, 1.5f,
-0.5f, -0.5f, 2.5f,
-0.5f,  0.5f, 2.5f,

 0.5f,  0.5f, 2.5f,
 0.5f,  0.5f, 1.5f,
 0.5f, -0.5f, 1.5f,
 0.5f, -0.5f, 1.5f,
 0.5f, -0.5f, 2.5f,
 0.5f,  0.5f, 2.5f,

-0.5f, -0.5f, 1.5f,
 0.5f, -0.5f, 1.5f,
 0.5f, -0.5f, 2.5f,
 0.5f, -0.5f, 2.5f,
-0.5f, -0.5f, 2.5f,
-0.5f, -0.5f, 1.5f,

-0.5f,  0.5f, 1.5f,
 0.5f,  0.5f, 1.5f,
 0.5f,  0.5f, 2.5f,
 0.5f,  0.5f, 2.5f,
-0.5f,  0.5f, 2.5f,
-0.5f,  0.5f, 1.5f,

};

float cube3[] = {

-0.5f, -0.5f, -2.5f,
 0.5f, -0.5f, -2.5f,
 0.5f,  0.5f, -2.5f,
 0.5f,  0.5f, -2.5f,
-0.5f,  0.5f, -2.5f,
-0.5f, -0.5f, -2.5f,

-0.5f, -0.5f, -1.5f,
 0.5f, -0.5f, -1.5f,
 0.5f,  0.5f, -1.5f,
 0.5f,  0.5f, -1.5f,
-0.5f,  0.5f, -1.5f,
-0.5f, -0.5f, -1.5f,

-0.5f,  0.5f, -1.5f,
-0.5f,  0.5f, -2.5f,
-0.5f, -0.5f, -2.5f,
-0.5f, -0.5f, -2.5f,
-0.5f, -0.5f, -1.5f,
-0.5f,  0.5f, -1.5f,

 0.5f,  0.5f, -1.5f,
 0.5f,  0.5f, -2.5f,
 0.5f, -0.5f, -2.5f,
 0.5f, -0.5f, -2.5f,
 0.5f, -0.5f, -1.5f,
 0.5f,  0.5f, -1.5f,

-0.5f, -0.5f, -2.5f,
 0.5f, -0.5f, -2.5f,
 0.5f, -0.5f, -1.5f,
 0.5f, -0.5f, -1.5f,
-0.5f, -0.5f, -1.5f,
-0.5f, -0.5f, -2.5f,

-0.5f,  0.5f, -2.5f,
 0.5f,  0.5f, -2.5f,
 0.5f,  0.5f, -1.5f,
 0.5f,  0.5f, -1.5f,
-0.5f,  0.5f, -1.5f,
-0.5f,  0.5f, -2.5f,

};

#define numVBOs 3
#define numVAOs 1
GLuint VBO[numVBOs];
GLuint VAO[numVAOs];

GLuint renderingProgram;
GLuint renderingProgram1;

char window_title[] = "Harmadik Feladat";

glm::mat4 model, view, projection;

float deltaTime = 0.0f, lastTime = 0.0f;
float t = 0.0f;

//Kamera kezdőpozició
float r = 9.0f;
glm::vec3 cameraPos = glm::vec3(r, 0.0f, 0.0f);

//A kamera mindig az origóba nézzen.
glm::vec3 cameraTarget = glm::vec3(0.0f, 0.0f, 0.0f);

//Az UP vektorunk számára vegyük fel a (0; 0; 1) értéket.
glm::vec3 up = glm::vec3(0.0f, 0.0f, 1.0f);
glm::vec3 cameraMovingY = glm::vec3(0.0f, 1.0f, 0.0f);
glm::vec3 cameraMovingZ = glm::vec3(0.0f, 0.0f, 1.0f);

void computeCameraMatrices()
{

	view = glm::lookAt(cameraPos, cameraTarget, up);
	//A vetítés legyen perspective 55 értékkel.
	projection = glm::perspective(glm::radians(55.0f), (float)WIN_WIDTH / (float)WIN_HEIGHT, 0.1f, 100.0f);
}

void computeModelMatrices()
{
	model = glm::mat4(1.0f);
	model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
}

bool checkOpenGLError() {
	bool foundError = false;
	int glErr = glGetError();
	while (glErr != GL_NO_ERROR) {
		cout << "glError: " << glErr << endl;
		foundError = true;
		glErr = glGetError();
	}
	return foundError;
}

void printShaderLog(GLuint shader) {
	int len = 0;
	int chWrittn = 0;
	char* log;
	glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &len);
	if (len > 0) {
		log = (char*)malloc(len);
		glGetShaderInfoLog(shader, len, &chWrittn, log);
		cout << "Shader Info Log: " << log << endl;
		free(log);
	}
}

void printProgramLog(int prog) {
	int len = 0;
	int chWrittn = 0;
	char* log;
	glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &len);
	if (len > 0) {
		log = (char*)malloc(len);
		glGetProgramInfoLog(prog, len, &chWrittn, log);
		cout << "Program Info Log: " << log << endl;
		free(log);
	}
}

string readShaderSource(const char* filePath) {
	string content;
	ifstream fileStream(filePath, ios::in);
	string line = "";

	while (!fileStream.eof()) {
		getline(fileStream, line);
		content.append(line + "\n");
	}
	fileStream.close();
	return content;
}

GLuint createShaderProgram() {

	GLint vertCompiled;
	GLint fragCompiled;
	GLint linked;

	string vertShaderStr = readShaderSource("vertexShader.glsl");
	string fragShaderStr = readShaderSource("fragmentShader.glsl");

	GLuint vShader = glCreateShader(GL_VERTEX_SHADER);
	GLuint fShader = glCreateShader(GL_FRAGMENT_SHADER);

	const char* vertShaderSrc = vertShaderStr.c_str();
	const char* fragShaderSrc = fragShaderStr.c_str();

	glShaderSource(vShader, 1, &vertShaderSrc, NULL);
	glShaderSource(fShader, 1, &fragShaderSrc, NULL);

	glCompileShader(vShader);
	checkOpenGLError();
	glGetShaderiv(vShader, GL_COMPILE_STATUS, &vertCompiled);
	if (vertCompiled != 1) {
		cout << "vertex compilation failed" << endl;
		printShaderLog(vShader);
	}

	glCompileShader(fShader);
	checkOpenGLError();
	glGetShaderiv(vShader, GL_COMPILE_STATUS, &fragCompiled);
	if (fragCompiled != 1) {
		cout << "fragment compilation failed" << endl;
		printShaderLog(fShader);
	}

	GLuint vfProgram = glCreateProgram();
	glAttachShader(vfProgram, vShader);
	glAttachShader(vfProgram, fShader);

	glLinkProgram(vfProgram);
	checkOpenGLError();
	glGetProgramiv(vfProgram, GL_LINK_STATUS, &linked);
	if (linked != 1) {
		cout << "linking failed" << endl;
		printProgramLog(vfProgram);
	}

	glDeleteShader(vShader);
	glDeleteShader(fShader);

	return vfProgram;
}

void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	float cameraSpeed = 4.0f * deltaTime;

	if (key == GLFW_KEY_UP && action == GLFW_REPEAT)
	{
		cameraPos += cameraSpeed * cameraMovingZ;
	}

	if (key == GLFW_KEY_DOWN && action == GLFW_REPEAT)
	{

		cameraPos -= cameraSpeed * cameraMovingZ;
	}

	if (key == GLFW_KEY_LEFT && action == GLFW_REPEAT)
	{
		t += 0.02;
		cameraPos.x = r * sin(t);
		cameraPos.y = r * cos(t);
		cameraPos += cameraSpeed * glm::normalize(glm::cross(cameraMovingY, up));
	}

	if (key == GLFW_KEY_RIGHT && action == GLFW_REPEAT)
	{
		t -= 0.02;
		cameraPos.x = r * sin(t);
		cameraPos.y = r * cos(t);
		cameraPos -= cameraSpeed * glm::normalize(glm::cross(cameraMovingY, up));
	}
}

void cursorPosCallback(GLFWwindow* window, double xPos, double yPos)
{

}

void mouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{

}

void init(GLFWwindow* window) {

	renderingProgram = createShaderProgram();

	glGenBuffers(numVBOs, VBO);
	glGenVertexArrays(numVAOs, VAO);

	glBindBuffer(GL_ARRAY_BUFFER, VBO[0]);

	glBufferData(GL_ARRAY_BUFFER, sizeof(cube1), cube1, GL_STATIC_DRAW);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindVertexArray(VAO[0]);

	glBindBuffer(GL_ARRAY_BUFFER, VBO[0]);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindBuffer(GL_ARRAY_BUFFER, VBO[1]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(cube2), cube2, GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(VAO[0]);
	glBindBuffer(GL_ARRAY_BUFFER, VBO[1]);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindBuffer(GL_ARRAY_BUFFER, VBO[2]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(cube3), cube3, GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(VAO[0]);
	glBindBuffer(GL_ARRAY_BUFFER, VBO[2]);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glEnable(GL_DEPTH_TEST);
	glClearColor(0.0, 0.0, 0.0, 1.0);
}

void display(GLFWwindow* window, double currentTime) {

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glUseProgram(renderingProgram);

	computeModelMatrices();
	computeCameraMatrices();

	unsigned int modelLoc = glGetUniformLocation(renderingProgram, "model");
	unsigned int viewLoc = glGetUniformLocation(renderingProgram, "view");
	unsigned int projectionLoc = glGetUniformLocation(renderingProgram, "projection");

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projection));

	glBindVertexArray(VAO[0]);
	glBindVertexBuffer(0, VBO[0], 0, 3 * sizeof(float));
	glDrawArrays(GL_TRIANGLES, 0, 36);

	glBindVertexBuffer(0, VBO[1], 0, 3 * sizeof(float));
	glDrawArrays(GL_TRIANGLES, 0, 36);

	glBindVertexBuffer(0, VBO[2], 0, 3 * sizeof(float));
	glDrawArrays(GL_TRIANGLES, 0, 36);

	glBindVertexArray(0);
}

void framebufferSizeCallback(GLFWwindow* window, int width, int height) {
	glViewport(0, 0, width, height);
}

void cleanUpScene() {
	glDeleteVertexArrays(numVAOs, VAO);
	glDeleteBuffers(numVBOs, VBO);

	glDeleteProgram(renderingProgram);
	glDeleteProgram(renderingProgram1);
}

int main(void) {

	if (!glfwInit()) { exit(EXIT_FAILURE); }

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	GLFWwindow* window = glfwCreateWindow(WIN_WIDTH, WIN_HEIGHT, window_title, NULL, NULL);

	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebufferSizeCallback);
	glfwSetKeyCallback(window, keyCallback);
	glfwSetMouseButtonCallback(window, mouseButtonCallback);
	if (glewInit() != GLEW_OK) { exit(EXIT_FAILURE); }
	glfwSwapInterval(1);

	init(window);

	while (!glfwWindowShouldClose(window)) {
		double currentTime = glfwGetTime();
		deltaTime = currentTime - lastTime;
		lastTime = currentTime;
		display(window, glfwGetTime());
		glfwSwapBuffers(window);
		glfwPollEvents();
	}
	glfwDestroyWindow(window);
	cleanUpScene();
	glfwTerminate();
	exit(EXIT_SUCCESS);
}